# TPBigProject
See description.txt

To run use:  
mkdir build  
cd build  
cmake ..  
make  
make install
